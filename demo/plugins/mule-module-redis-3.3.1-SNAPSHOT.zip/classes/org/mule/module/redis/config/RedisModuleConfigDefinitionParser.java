
package org.mule.module.redis.config;

import org.apache.commons.lang.StringUtils;
import org.mule.api.lifecycle.Disposable;
import org.mule.api.lifecycle.Initialisable;
import org.mule.config.spring.MuleHierarchicalBeanDefinitionParserDelegate;
import org.mule.config.spring.parsers.generic.AutoIdUtils;
import org.mule.module.redis.adapters.RedisModuleLifecycleAdapter;
import org.mule.util.TemplateParser;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.w3c.dom.Element;

public class RedisModuleConfigDefinitionParser
    implements BeanDefinitionParser
{

    /**
     * Mule Pattern Info
     * 
     */
    private TemplateParser.PatternInfo patternInfo;

    public RedisModuleConfigDefinitionParser() {
        patternInfo = TemplateParser.createMuleStyleParser().getStyle();
    }

    public BeanDefinition parse(Element element, ParserContext parserContent) {
        String name = element.getAttribute("name");
        if ((name == null)||StringUtils.isBlank(name)) {
            element.setAttribute("name", AutoIdUtils.getUniqueName(element, "mule-bean"));
        }
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(RedisModuleLifecycleAdapter.class.getName());
        if (Initialisable.class.isAssignableFrom(RedisModuleLifecycleAdapter.class)) {
            builder.setInitMethodName(Initialisable.PHASE_NAME);
        }
        if (Disposable.class.isAssignableFrom(RedisModuleLifecycleAdapter.class)) {
            builder.setDestroyMethodName(Disposable.PHASE_NAME);
        }
        if ((element.getAttribute("host")!= null)&&(!StringUtils.isBlank(element.getAttribute("host")))) {
            builder.addPropertyValue("host", element.getAttribute("host"));
        }
        if ((element.getAttribute("port")!= null)&&(!StringUtils.isBlank(element.getAttribute("port")))) {
            builder.addPropertyValue("port", element.getAttribute("port"));
        }
        if ((element.getAttribute("connectionTimeout")!= null)&&(!StringUtils.isBlank(element.getAttribute("connectionTimeout")))) {
            builder.addPropertyValue("connectionTimeout", element.getAttribute("connectionTimeout"));
        }
        if ((element.getAttribute("reconnectionFrequency")!= null)&&(!StringUtils.isBlank(element.getAttribute("reconnectionFrequency")))) {
            builder.addPropertyValue("reconnectionFrequency", element.getAttribute("reconnectionFrequency"));
        }
        if ((element.getAttribute("password")!= null)&&(!StringUtils.isBlank(element.getAttribute("password")))) {
            builder.addPropertyValue("password", element.getAttribute("password"));
        }
        if ((element.getAttribute("poolConfig-ref")!= null)&&(!StringUtils.isBlank(element.getAttribute("poolConfig-ref")))) {
            builder.addPropertyValue("poolConfig", new RuntimeBeanReference(element.getAttribute("poolConfig-ref")));
        }
        BeanDefinition definition = builder.getBeanDefinition();
        definition.setAttribute(MuleHierarchicalBeanDefinitionParserDelegate.MULE_NO_RECURSE, Boolean.TRUE);
        return definition;
    }

}
