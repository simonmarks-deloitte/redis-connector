
package org.mule.module.redis.config;

import java.util.List;
import org.apache.commons.lang.StringUtils;
import org.mule.config.spring.MuleHierarchicalBeanDefinitionParserDelegate;
import org.mule.config.spring.util.SpringXMLUtils;
import org.mule.module.redis.sources.SubscribeMessageSource;
import org.mule.util.TemplateParser;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.beans.factory.xml.BeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.util.xml.DomUtils;
import org.w3c.dom.Element;

public class SubscribeDefinitionParser
    implements BeanDefinitionParser
{

    /**
     * Mule Pattern Info
     * 
     */
    private TemplateParser.PatternInfo patternInfo;

    public SubscribeDefinitionParser() {
        patternInfo = TemplateParser.createMuleStyleParser().getStyle();
    }

    public BeanDefinition parse(Element element, ParserContext parserContent) {
        BeanDefinitionBuilder builder = BeanDefinitionBuilder.rootBeanDefinition(SubscribeMessageSource.class.getName());
        String configRef = element.getAttribute("config-ref");
        if ((configRef!= null)&&(!StringUtils.isBlank(configRef))) {
            builder.addPropertyValue("moduleObject", configRef);
        }
        Element channelsListElement = null;
        channelsListElement = DomUtils.getChildElementByTagName(element, "channels");
        List<Element> channelsListChilds = null;
        if (channelsListElement!= null) {
            String channelsRef = channelsListElement.getAttribute("ref");
            if ((channelsRef!= null)&&(!StringUtils.isBlank(channelsRef))) {
                if ((!channelsRef.startsWith(patternInfo.getPrefix()))&&(!channelsRef.endsWith(patternInfo.getSuffix()))) {
                    builder.addPropertyValue("channels", new RuntimeBeanReference(channelsRef));
                } else {
                    builder.addPropertyValue("channels", channelsRef);
                }
            } else {
                ManagedList channels = new ManagedList();
                channelsListChilds = DomUtils.getChildElementsByTagName(channelsListElement, "channel");
                if (channelsListChilds!= null) {
                    for (Element channelsChild: channelsListChilds) {
                        String valueRef = channelsChild.getAttribute("value-ref");
                        if ((valueRef!= null)&&(!StringUtils.isBlank(valueRef))) {
                            if ((!valueRef.startsWith(patternInfo.getPrefix()))&&(!valueRef.endsWith(patternInfo.getSuffix()))) {
                                channels.add(new RuntimeBeanReference(valueRef));
                            } else {
                                channels.add(valueRef);
                            }
                        } else {
                            channels.add(channelsChild.getTextContent());
                        }
                    }
                }
                builder.addPropertyValue("channels", channels);
            }
        }
        BeanDefinition definition = builder.getBeanDefinition();
        definition.setAttribute(MuleHierarchicalBeanDefinitionParserDelegate.MULE_NO_RECURSE, Boolean.TRUE);
        MutablePropertyValues propertyValues = parserContent.getContainingBeanDefinition().getPropertyValues();
        propertyValues.addPropertyValue("messageSource", definition);
        return definition;
    }

    protected String getAttributeValue(Element element, String attributeName) {
        if (!StringUtils.isEmpty(element.getAttribute(attributeName))) {
            return element.getAttribute(attributeName);
        }
        return null;
    }

    private String generateChildBeanName(Element element) {
        String id = SpringXMLUtils.getNameOrId(element);
        if (StringUtils.isBlank(id)) {
            String parentId = SpringXMLUtils.getNameOrId(((Element) element.getParentNode()));
            return ((("."+ parentId)+":")+ element.getLocalName());
        } else {
            return id;
        }
    }

}
