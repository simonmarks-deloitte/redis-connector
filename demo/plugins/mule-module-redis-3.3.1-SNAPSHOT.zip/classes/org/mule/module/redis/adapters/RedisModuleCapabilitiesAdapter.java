
package org.mule.module.redis.adapters;

import org.mule.api.Capabilities;
import org.mule.api.Capability;


/**
 * A <code>RedisModuleCapabilitiesAdapter</code> is a wrapper around {@link org.mule.module.redis.RedisModule } that implements {@link org.mule.api.Capabilities} interface.
 * 
 */
public class RedisModuleCapabilitiesAdapter
    extends org.mule.module.redis.RedisModule
    implements Capabilities
{


    /**
     * Returns true if this module implements such capability
     * 
     */
    public boolean isCapableOf(Capability capability) {
        if (capability == Capability.LIFECYCLE_CAPABLE) {
            return true;
        }
        return false;
    }

}
