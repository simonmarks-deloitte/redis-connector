
package org.mule.module.redis.config;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;


/**
 * Registers bean definitions parsers for handling elements in <code>http://www.mulesoft.org/schema/mule/redis</code>.
 * 
 */
public class RedisModuleNamespaceHandler
    extends NamespaceHandlerSupport
{


    /**
     * Invoked by the {@link DefaultBeanDefinitionDocumentReader} after construction but before any custom elements are parsed. 
     * @see NamespaceHandlerSupport#registerBeanDefinitionParser(String, BeanDefinitionParser)
     * 
     */
    public void init() {
        registerBeanDefinitionParser("config", new RedisModuleConfigDefinitionParser());
        registerBeanDefinitionParser("set", new SetDefinitionParser());
        registerBeanDefinitionParser("get", new GetDefinitionParser());
        registerBeanDefinitionParser("hash-set", new SetInHashDefinitionParser());
        registerBeanDefinitionParser("hash-get", new GetFromHashDefinitionParser());
        registerBeanDefinitionParser("list-push", new PushToListDefinitionParser());
        registerBeanDefinitionParser("list-pop", new PopFromListDefinitionParser());
        registerBeanDefinitionParser("set-add", new AddToSetDefinitionParser());
        registerBeanDefinitionParser("set-pop", new PopFromSetDefinitionParser());
        registerBeanDefinitionParser("set-fetch-random-member", new RandomMemberFromSetDefinitionParser());
        registerBeanDefinitionParser("sorted-set-add", new AddToSortedSetDefinitionParser());
        registerBeanDefinitionParser("sorted-set-select-range-by-index", new GetRangeByIndexDefinitionParser());
        registerBeanDefinitionParser("sorted-set-select-range-by-score", new GetRangeByScoreDefinitionParser());
        registerBeanDefinitionParser("publish", new PublishDefinitionParser());
        registerBeanDefinitionParser("subscribe", new SubscribeDefinitionParser());
    }

}
